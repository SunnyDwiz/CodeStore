﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

using Lib_EmployeeModel;

namespace EmpWebsite
{
    public partial class ManageProfile : System.Web.UI.Page
    {

        string str = ConfigurationManager.ConnectionStrings["CrudCon"].ToString();
        SqlConnection con;
        SqlCommand cmd;
        string Skillset = " ";
        string religion;
        string IsActive;
        SqlDataReader sdr;
        string USerId = "1";

        List<EmpModel> LsEmps;

        Dictionary<int, string> CityTel = new Dictionary<int, string>();
        Dictionary<int, string> CityBr = new Dictionary<int, string>();
        Dictionary<int, string> CityJhar = new Dictionary<int, string>();
        Dictionary<int, string> CityMp = new Dictionary<int, string>();

        protected void Page_Load(object sender, EventArgs e)
        {
            EmpModel ObjEmployee = new EmpModel();
            if (Session["Emp"]!= null)
            {
                LsEmps = (List<EmpModel>)Session["Emp"];
                ObjEmployee = ((List<EmpModel>)Session["Emp"])[0];
                grdViewProfile.DataSource = LsEmps;
                grdViewProfile.DataBind();
            }
            if (Request.QueryString["id"]!= null)
            {
                USerId = Convert.ToString(Request.QueryString["id"]);

                SelectData(USerId);
            }
            
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteData();
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateData();
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            InsertData();
        }


        protected void StateList()
        {
            Dictionary<int, string> listState = new Dictionary<int, string>();
            listState.Add(0, "Select Any State");
            listState.Add(1, "Telangana");
            listState.Add(2, "Jharkhand");
            listState.Add(3, "MP");
            listState.Add(5, "Biahr");
            drpState.DataSource = listState;
            drpState.DataTextField = "Value";
            drpState.DataValueField = "Key";
            drpState.DataBind();
        }

        protected void TelCity()
        { // Dictionary<int, string> CityTel = new Dictionary<int, string>();
            CityTel.Add(0, "Select City");
            CityTel.Add(1, "hyderabad");
            CityTel.Add(2, "Secunderabad");
            CityTel.Add(3, "kazipet");
            CityTel.Add(4, "Suryapet");
            CityTel.Add(5, "Karimnagar");
            drpCity.DataSource = CityTel;
            drpCity.DataTextField = "Value";
            drpCity.DataValueField = "Key";
            drpCity.DataBind();

        }

        protected void MPCity()
        {
            // Dictionary<int, string> CityMp = new Dictionary<int, string>();
            CityMp.Add(0, "Select City");
            CityMp.Add(1, "Indor");
            CityMp.Add(2, "Bhopal");
            CityMp.Add(3, "Sagar");
            CityMp.Add(4, "Gwalior");
            CityMp.Add(5, "Rewa");
            drpCity.DataSource = CityMp;
            drpCity.DataTextField = "Value";
            drpCity.DataValueField = "Key";
            drpCity.DataBind();
        }

        protected void BrCity()
        {
            //  Dictionary<int, string> CityBr = new Dictionary<int, string>();
            CityBr.Add(0, "Select City");
            CityBr.Add(1, "Patna");
            CityBr.Add(2, "Begusarai");
            CityBr.Add(3, "Muzaffarpur");
            CityBr.Add(4, "Gaya");
            CityBr.Add(5, "Nalanda");
            drpCity.DataSource = CityBr;
            drpCity.DataTextField = "Value";
            drpCity.DataValueField = "Key";
            drpCity.DataBind();
        }

        protected void JHCity()
        {
            //Dictionary<int, string> CityJhar = new Dictionary<int, string>();
            CityJhar.Add(0, "Select City");
            CityJhar.Add(1, "Ranchi");
            CityJhar.Add(2, "Jamsedpur");
            CityJhar.Add(3, "Bokaro");
            CityJhar.Add(4, "Dhanbad");
            CityJhar.Add(5, "Devghar");
            drpCity.DataSource = CityJhar;
            drpCity.DataTextField = "Value";
            drpCity.DataValueField = "Key";
            drpCity.DataBind();

        }

        protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (drpState.SelectedIndex == 0)
            {
                Response.Write("<script>alert('Plaese Select State')</script>");
                drpCity.SelectedIndex = 0;
            }

            else if (drpState.SelectedIndex == 1)
            {
                TelCity();
            }
            else if (drpState.SelectedIndex == 2)
            {
                JHCity();
            }
            else if (drpState.SelectedIndex == 3)
            {
                MPCity();
            }

            else if (drpState.SelectedIndex == 4)
            {
                BrCity();
            }
            else
            {
                Response.Write("<script>alert('Plaese Select State')</script>");
            }
        }

        public void InsertData()
        {
            
            if (chkBoostrap.Checked == true)
            {
                Skillset += " Bootstrap";
            }
            else if (chkBoostrap.Checked == false)
            {
                Skillset += "";
            }
            if (chkCsharp.Checked)
            {
                Skillset += "CSharp";
            }
            else if (chkCsharp.Checked == false)
            {
                Skillset += "";
            }

            if (chkIsActive.Checked)
            {
                IsActive = "0";
            }

            if (rdHindu.Checked)
            {
                religion = "Hindu";
            }
            if (rdMuslim.Checked)
            {
                religion = "Muslim";
            }

            con = new SqlConnection("str");
            cmd = new SqlCommand("Sp_InsertEmpData");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = con;

            cmd.Parameters.AddWithValue("@EmpName", txtEmpName.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@EState", drpState.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@City", drpCity.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@UserName", txtUserName.Text);
            cmd.Parameters.AddWithValue("@EPassword", txtEPassword.Text);
            cmd.Parameters.AddWithValue("@Gender", drpGender.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Skill", Skillset);
            cmd.Parameters.AddWithValue("@Religion", religion);
            cmd.Parameters.AddWithValue("@IsActive", IsActive);
            cmd.Parameters.AddWithValue("@RollId", drpRoleId.SelectedItem.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void DeleteData()
        {
            con = new SqlConnection("str");
            cmd = new SqlCommand("Sp_DeleteEmpData");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = con;

            cmd.Parameters.AddWithValue("@EmpId", txtEmpId.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
    

        public void UpdateData()
    {
        con = new SqlConnection("str");
        cmd = new SqlCommand("Sp_UpdateEmpData");
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;

        cmd.Parameters.AddWithValue("@EmpId", txtEmpId.Text);
        cmd.Parameters.AddWithValue("@EmpName", txtEmpName.Text);
        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
        cmd.Parameters.AddWithValue("@EState", drpState.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@City", drpCity.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
        cmd.Parameters.AddWithValue("@UserName", txtUserName.Text);
        cmd.Parameters.AddWithValue("@EPassword", txtEPassword.Text);
        cmd.Parameters.AddWithValue("@Gender", drpGender.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@Skill", Skillset);
        cmd.Parameters.AddWithValue("@Religion", religion);
        cmd.Parameters.AddWithValue("@IsActive", chkIsActive.Checked);
        cmd.Parameters.AddWithValue("@RollId", drpRoleId.SelectedItem.Text);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }

        public void SelectData(string id)
    {
        con = new SqlConnection("str");
        cmd = new SqlCommand("Sp_SelectEmpData");
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.Parameters.AddWithValue("@EmpId", id);
        con.Open();
            sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                txtEmpId.Text = Convert.ToString(sdr["EmpId"]);
            }

            con.Close();
    }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            SelectData(USerId);
        }
    }
}

