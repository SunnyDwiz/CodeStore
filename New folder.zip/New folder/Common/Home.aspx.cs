﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EmpWebsite
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["name"]!=null)
            {
                string Name= "Welcome " + Request.QueryString["Name"];
                Response.Write("<script>alert('"+Name+"');</script>");
            }

           
        }
    }
}