﻿using System;
using System.Collections.Generic;
using EmployeeCL;

namespace EmpWebsite
{
    public partial class ManageProfile : System.Web.UI.Page
    {
        List<Employee> LsEmps;

        protected void Page_Load(object sender, EventArgs e)
        {
            Employee ObjEmployee = new Employee();
            if (Session["Emp"]!= null)
            {
                LsEmps = (List<Employee>)Session["Emp"];
                ObjEmployee = ((List<Employee>)Session["Emp"])[0];
                //Response.Write(ObjEmployee.EmpName);

                grdViewProfile.DataSource = LsEmps;
                //int[] EmpIdArr = LsEmps.Select(x => x.EmpId).ToArray();
                //grdViewProfile.DataKeyNames = Array.ConvertAll(EmpIdArr, y => y.ToString());  
                //grdViewProfile.DataKeyNames = ObjEmployee[].EmpId;
                grdViewProfile.DataBind();
            }
            
        }
    }
}