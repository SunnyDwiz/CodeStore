﻿using System;
using System.Configuration;
using System.Data.SqlClient;


namespace EmpWebsite
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ToString());
            SqlCommand cmd = new SqlCommand("select * from tbEmpDetails", con);
            Response.Redirect("~/Admin/AddEmployee.aspx");
        }
    }
}